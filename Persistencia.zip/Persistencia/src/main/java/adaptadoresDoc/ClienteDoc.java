package adaptadoresDoc;

import dominio.Cliente;
import org.bson.Document;

/**
 * Clase de utilería que adapta los documentos de los clientes a entidades
 * y viceversa mediante métodos estáticos puros.
 * 
 * @author aron
 */
public final class ClienteDoc {

    private ClienteDoc() {}

    /**
     * Transforma un documento de MongoDB a una entidad Cliente.
     */
    public static Cliente toEntity(Document doc) {
        if (doc == null) return null;
        
        Cliente cliente = new Cliente();

        // Mapeo del ID usando el adaptador base de utilerías
        cliente.setCorreo(doc.getString("correo"));
        cliente.setTelefono(doc.getString("telefono"));

        // Llamada estática directa a PersonaDoc para rellenar nombres y apellidos
        PersonaDoc.llenarPersonaDesdeDoc(doc, cliente);

        return cliente;
    }
    
    /**
     * Transformación para estar embebido dentro de una
     * transacción. Actualmente solo llama al método toEntity
     * pues no hay cambios. Pero el día que cambie la forma en la
     * cual se cambie el almacenado, la venta o solicitud nunca se
     * va a enterar
     * 
     * @param doc
     * @return 
     */
    public static Cliente toEntityEmbebido(Document doc) {
        return toEntity(doc);
    }

    /**
     * Transforma una entidad Cliente a un documento de MongoDB.
     */
    public static Document toDocument(Cliente cliente) {
        if (cliente == null) return null;
        
        Document doc = new Document();
        
        doc.put("correo", cliente.getCorreo());
        doc.put("telefono", cliente.getTelefono());

        // Llamada estática directa a PersonaDoc para volcar nombres y apellidos al documento
        PersonaDoc.llenarDocDesdePersona(doc, cliente);

        return doc;
    }
    
    /**
     * Misma lógica que entityEmbebido
     * 
     * @param cliente
     * @return 
     */
    public static Document toDocumentEmbebido(Cliente cliente) {
        return toDocument(cliente);
    }
}