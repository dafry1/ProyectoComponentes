/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package bo;

import DTOS.EmpleadoDTO;
import java.util.List;

/**
 *
 * @author DANIEL
 */
public interface IEmpleadoBO {
    public List<EmpleadoDTO> consultarEmpleados();
    public EmpleadoDTO verificarEmpleado(String usuario, String password);
}
