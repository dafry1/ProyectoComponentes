package ensambladores;

import DTOS.ClienteDTO;
import DTOS.DetallesSolicitudDTO;
import DTOS.DetallesVentaDTO;
import DTOS.EmpleadoDTO;
import DTOS.PersonaDTO;
import DTOS.PiezaDTO;
import DTOS.VentaDTO;
import excepciones.PresentacionException;
import java.util.List;

/**
 * Aplica el patrón ensamblador. A diferencia de una fábrica
 * que te dice "ten esto", al ensamblador le dices "ordéname
 * en una clase los datos que aquí te traigo". No aplica para
 * todos los DTO, naturalmente, sino para los que son creados
 * en presentación
 * 
 * @author Andre
 */
public class EnsambladorDTO implements IEnsambladorDTO {

    /**
     * Obtiene la información necesaria para crear el DTO
     * de un detalle de una venta de forma centralizada
     * 
     * @param cantidad de la piza en específico
     * @param pieza que está en el detalle
     * 
     * @return detalle listo
     */
    @Override
    public DetallesVentaDTO ensamblarDetalleVentaDTO(int cantidad, PiezaDTO pieza) {
        double costo = pieza.getCostoPieza();
        DetallesVentaDTO detalle = new DetallesVentaDTO();
        detalle.setCantidad(cantidad);
        detalle.setCosto(costo);
        detalle.setPieza(pieza);
        detalle.setSubtotal(costo*cantidad);
        return detalle;
    }
    
    @Override
    public DetallesSolicitudDTO ensamblarDetalleSolicitudDTO(int cantidad, PiezaDTO pieza) {
        double costo = pieza.getCostoPieza();
        DetallesSolicitudDTO detalle = new DetallesSolicitudDTO();
        detalle.setCantidad(cantidad);
        detalle.setCosto(costo);
        detalle.setPieza(pieza);
        detalle.setSubtotal(costo*cantidad);
        return detalle;
    }
}